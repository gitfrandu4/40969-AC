/*
 * AC - Practica 4
 *
 * Tutorial 1: hola_chicos_y_chicas
 * Version secuencial
 *
 * y = A . x
 * 
 */
#include <stdio.h>

int main()
{
  printf("Hola chicos de AC!\n");
  printf("Hola chicas de AC!\n");

  return 0;
}
